<?php @include('header.php') ?>

<table align="center">
    <tr>
        <td align="center" height="80px">[ ROOMY EVENT ]</td>
    </tr>
    <tr>
        <td height="80px"></td>
    </tr>
    <tr>
        <td align="center">
            <table width="300">
                <tr>
                    <td width='50' align='center' height='60'>
                        <img src='images/1r.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' One '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/1b.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' One '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/1l.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' One '>
                    <td>
                </tr>
                <tr>
                    <td width='50' align='center' height='60'>
                        <img src='images/2r.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Two '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/2b.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Two '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/2l.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Two '>
                    <td>
                </tr>
                <tr>
                    <td width='50' align='center' height='60'>
                        <img src='images/3r.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Three '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/3b.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Three '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/3l.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Three '>
                    <td>
                </tr>
                <tr>
                    <td width='50' align='center' height='60'>
                        <img src='images/4r.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Four '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/4b.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Four '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/4l.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Four '>
                    <td>
                </tr>
                <tr>
                    <td width='50' align='center' height='60'>
                        <img src='images/5r.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Five '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/5b.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Five '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/5l.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Five '>
                    <td>
                </tr>
                <tr>
                    <td width='50' align='center' height='60'>
                        <img src='images/6r.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Six '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/6b.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Six '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/6l.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Six '>
                    <td>
                </tr>
                <tr>
                    <td width='50' align='center' height='60'>
                        <img src='images/7r.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Seven '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/7b.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Seven '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/7l.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Seven '>
                    <td>
                </tr>
                <tr>
                    <td width='50' align='center' height='60'>
                        <img src='images/8r.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Eight '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/8b.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Eight '>
                    <td>
                    <td width='50' align='center' height='60'>
                        <img src='images/8l.jpg' border='0' class='imgDisplay' style='cursor:pointer;' title=' Eight '>
                    <td>
                </tr>
            </table>
        </td>
    <tr>
        <td height="80"></td>
    </tr>
    <tr>
        <td align="center">
            <font color="Crimson">
                <b>
                    [ <a class="refresh" href="">Refresh</a> ]
                </b>
            </font>
        </td>
    </tr>
    <tr>
        <td height="80"></td>
    </tr>
    <tr>
        <td align="center">
                <b>
                    <div class="eventName">Rewards 250-390 point
                        <span>
                            <img src="images/250-390.jpg" alt="" class="score">
                        </span>
                    </div>
                </b>
        </td>
    </tr>
    <tr>
        <td height="80"></td>
    </tr>
    <tr>
        <td align="center">
                <b>
                    <div class="eventName">Rewards 400-490 point
                        <span>
                            <img src="images/400-490.jpg" alt="" class="score">
                        </span>
                    </div>
                </b>
        </td>
    </tr>
    <tr>
        <td height="80"></td>
    </tr>
    <tr>
        <td align="center">
                <b>
                    <div class="eventName">Rewards 500+ point
                        <span>
                            <img src="images/500.jpg" alt="" class="score">
                        </span>
                    </div>
                </b>
        </td>
    </tr>
    <tr>
        <td height="80"></td>
    </tr>
    <tr>
        <td align="center">
                <b>
                    <div class="eventName">Score Table
                        <span>
                            <img src="images/event-point-table.jpg" alt="" class="score">
                        </span>
                    </div>
                </b>
        </td>
    </tr>
    <tr>
        <td height="80"></td>
    </tr>